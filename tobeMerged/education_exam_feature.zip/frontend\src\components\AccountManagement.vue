<template>
  <div>
    <h2>账户管理</h2>
    <el-form>
      <el-input placeholder="用户名"></el-input>
      <el-input type="password" placeholder="密码"></el-input>
      <el-button>更新</el-button>
    </el-form>
  </div>
</template>

<script>
export default {
  // 添加逻辑
}
</script>
